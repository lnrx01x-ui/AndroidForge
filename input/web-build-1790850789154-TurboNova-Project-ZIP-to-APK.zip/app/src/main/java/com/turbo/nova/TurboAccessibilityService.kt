package com.turbo.nova

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray

class TurboAccessibilityService:AccessibilityService(){
 private val handler=Handler(Looper.getMainLooper())
 private val prefs by lazy{getSharedPreferences("turbo_nova",MODE_PRIVATE)}
 private var busy=false
 override fun onAccessibilityEvent(event:AccessibilityEvent?){
  if(event==null||busy)return
  val root=rootInActiveWindow?:return
  val p=event.packageName?.toString().orEmpty()
  if(!p.contains("settings",true))return
  val texts=collect(root).map{it.lowercase()}
  val all=texts.joinToString(" | ");val stage=prefs.getInt("stage",0)
  when{
   stage<=1 && isStorage(all) && hasClear(all)->{
    val n=find(root,::isClear);if(n!=null){busy=true;n.performAction(AccessibilityNodeInfo.ACTION_CLICK);n.recycle();prefs.edit().putInt("stage",2).apply();handler.postDelayed({performGlobalAction(GLOBAL_ACTION_BACK);busy=false},700)}
   }
   stage==0 && isAppInfo(all)->{
    val n=find(root,::isStorageLabel);if(n!=null){busy=true;n.performAction(AccessibilityNodeInfo.ACTION_CLICK);n.recycle();prefs.edit().putInt("stage",1).apply();handler.postDelayed({busy=false},650)}
   }
   stage==2 && isAppInfo(all)->{
    val n=find(root,::isForce);if(n!=null){busy=true;n.performAction(AccessibilityNodeInfo.ACTION_CLICK);n.recycle();prefs.edit().putInt("stage",3).apply();handler.postDelayed({busy=false},500)}
   }
   stage==3 && isConfirm(all)->{
    val n=find(root,::isForce);if(n!=null){busy=true;n.performAction(AccessibilityNodeInfo.ACTION_CLICK);n.recycle();prefs.edit().putInt("stage",4).apply();handler.postDelayed({busy=false;advance()},1000)}
   }
   stage==3 && isAppInfo(all)->handler.postDelayed({advance()},1200)
  }
 }
 override fun onInterrupt(){}
 private fun advance(){
  val a=try{JSONArray(prefs.getString("queue","[]")?: "[]")}catch(_:Exception){JSONArray()}
  val next=prefs.getInt("index",0)+1
  if(next>=a.length()){prefs.edit().putString("queue","[]").putInt("index",next).putInt("stage",0).apply();return}
  val pkg=a.optString(next);prefs.edit().putInt("index",next).putInt("stage",0).apply()
  handler.postDelayed({try{startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}catch(_:Exception){}},600)
 }
 private fun collect(n:AccessibilityNodeInfo):List<String>{val out=mutableListOf<String>();n.text?.toString()?.let{out.add(it)};n.contentDescription?.toString()?.let{out.add(it)};for(i in 0 until n.childCount){val c=n.getChild(i)?:continue;out.addAll(collect(c));c.recycle()};return out}
 private fun find(n:AccessibilityNodeInfo,pred:(String)->Boolean):AccessibilityNodeInfo?{
  val s=n.text?.toString()?:n.contentDescription?.toString().orEmpty()
  if(pred(s)&&n.isEnabled){var cur=AccessibilityNodeInfo.obtain(n);while(!cur.isClickable){val par=cur.parent;cur.recycle();cur=par?:return null};return cur}
  for(i in 0 until n.childCount){val c=n.getChild(i)?:continue;val got=find(c,pred);c.recycle();if(got!=null)return got};return null
 }
 private fun hasAny(s:String,vararg xs:String)=xs.any{s.contains(it,true)}
 private fun isClear(s:String)=hasAny(s,"clear cache","مسح ذاكرة التخزين المؤقت","مسح ذاكرة التخزين","مسح الكاش")
 private fun hasClear(s:String)=isClear(s)
 private fun isStorageLabel(s:String)=hasAny(s,"storage & cache","storage","التخزين","مساحة التخزين")
 private fun isForce(s:String)=hasAny(s,"force stop","إيقاف إجباري","فرض الإيقاف")
 private fun isStorage(s:String)=hasClear(s)||hasAny(s,"storage","التخزين")
 private fun isAppInfo(s:String)=isForce(s)&&isStorageLabel(s)
 private fun isConfirm(s:String)=hasAny(s,"do you want to force stop","force stop?","إيقاف إجباري؟","هل تريد إيقاف التطبيق")
}
