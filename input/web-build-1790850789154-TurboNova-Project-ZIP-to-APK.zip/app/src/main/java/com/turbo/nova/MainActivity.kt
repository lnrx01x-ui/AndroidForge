package com.turbo.nova

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONArray

data class AppItem(val name:String, val pkg:String, val icon:android.graphics.drawable.Drawable)

class MainActivity: AppCompatActivity() {
 private val apps=mutableListOf<AppItem>()
 private val prefs by lazy { getSharedPreferences("turbo_nova", MODE_PRIVATE) }
 private lateinit var list:LinearLayout
 private lateinit var search:TextInputEditText
 private lateinit var status:TextView
 private lateinit var count:TextView
 private lateinit var badge:TextView
 private val bg=Color.rgb(8,13,27); private val mint=Color.rgb(85,230,193)
 override fun onCreate(savedInstanceState:Bundle?){ super.onCreate(savedInstanceState); buildUi(); loadApps() }
 override fun onResume(){ super.onResume(); if(::badge.isInitialized) badge.text=if(enabled()) "● READY" else "● OFFLINE" }
 private fun buildUi(){
  val scroll=ScrollView(this).apply{setBackgroundColor(bg); fillViewport=true}
  val root=LinearLayout(this).apply{orientation=1; setPadding(dp(20),dp(24),dp(20),dp(28))}
  scroll.addView(root); setContentView(scroll)
  val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
  val logo=TextView(this).apply{ text="ϟ"; textSize=32f; gravity=Gravity.CENTER; setTextColor(bg); setBackgroundColor(mint) }
  head.addView(logo,LinearLayout.LayoutParams(dp(46),dp(46)))
  val branding=LinearLayout(this).apply{orientation=1; setPadding(dp(12),0,0,0)}
  branding.addView(label("T U R B O   N O V A",18,Color.WHITE,true))
  branding.addView(label("SMART DEVICE CARE",10,0xFF8E9AB8.toInt(),false))
  head.addView(branding,LinearLayout.LayoutParams(0,-2,1f))
  badge=label("● OFFLINE",11,0xFFFFCC80.toInt(),true); head.addView(badge); root.addView(head)
  root.addView(label("Your phone.\\nYour rules.",32,Color.WHITE,true).apply{setPadding(0,dp(28),0,0)})
  root.addView(label("إدارة أسرع للتطبيقات — بدون روت",15,0xFFAAB5D0.toInt(),false).apply{setPadding(0,dp(8),0,0)})
  val hero=MaterialCardView(this).apply{radius=dp(26).toFloat(); setCardBackgroundColor(0xFF171F38.toInt()); strokeWidth=dp(1); setStrokeColor(0xFF35335E.toInt())}
  val inside=LinearLayout(this).apply{orientation=1; setPadding(dp(20),dp(20),dp(20),dp(20))}
  inside.addView(label("T U R B O   S E S S I O N",11,0xFFAAB5D0.toInt(),true))
  count=label("Loading apps…",24,Color.WHITE,true); count.setPadding(0,dp(5),0,0); inside.addView(count)
  status=label("فعّل المساعد مرة واحدة لبدء الأتمتة.",13,0xFFAAB5D0.toInt(),false); status.setPadding(0,dp(12),0,0); inside.addView(status)
  val all=button("تشغيل Turbo للجميع  ↗",mint,bg); all.setOnClickListener{
   if(!enabled()){status.text="فعّل Turbo Nova من إعدادات إمكانية الوصول أولاً."; startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
   else if(apps.isNotEmpty()) startTurbo(apps.map{it.pkg})
  }; inside.addView(all,lp(-1,dp(54),top=18))
  val access=button("إعداد المساعد الذكي",0xFF222D49.toInt(),Color.WHITE); access.setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
  inside.addView(access,lp(-1,dp(48),top=10)); hero.addView(inside); root.addView(hero,lp(-1,-2,top=22))
  val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL; setPadding(0,dp(25),0,dp(6))}
  row.addView(label("تطبيقات Google Play",19,Color.WHITE,true),LinearLayout.LayoutParams(0,-2,1f))
  val refresh=label("تحديث ↻",13,mint,true).apply{setPadding(dp(8),dp(8),dp(8),dp(8));setOnClickListener{loadApps()}}
  row.addView(refresh); root.addView(row)
  search=TextInputEditText(this).apply{hint="ابحث عن تطبيق…"; setHintTextColor(0xFF7783A2.toInt());setTextColor(Color.WHITE); singleLine=true; setPadding(dp(14),dp(12),dp(14),dp(12));setBackgroundColor(0xFF11182C.toInt())}
  root.addView(search,lp(-1,dp(52)))
  list=LinearLayout(this).apply{orientation=1}; root.addView(list,lp(-1,-2,top=12))
  search.addTextChangedListener(object:TextWatcher{
   override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
   override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render(s.toString())}
   override fun afterTextChanged(s:Editable?){}
  })
  root.addView(label("PRIVATE BY DESIGN  •  NO ROOT  •  NO CLOUD",10,0xFF65718F.toInt(),false).apply{gravity=Gravity.CENTER;setPadding(0,dp(20),0,0)})
 }
 private fun loadApps(){
  apps.clear()
  for(i in packageManager.getInstalledApplications(PackageManager.GET_META_DATA)){
   if(i.packageName==packageName || i.flags and ApplicationInfo.FLAG_SYSTEM!=0) continue
   val fromPlay=try{val s=packageManager.getInstallSourceInfo(i.packageName);s.installingPackageName=="com.android.vending"||s.initiatingPackageName=="com.android.vending"}catch(_:Exception){false}
   if(fromPlay){val name=packageManager.getApplicationLabel(i).toString();val icon=try{packageManager.getApplicationIcon(i)}catch(_:Exception){getDrawable(android.R.drawable.sym_def_app_icon)!!};apps.add(AppItem(name,i.packageName,icon))}
  }
  apps.sortBy{it.name.lowercase()}; count.text="${apps.size} apps ready"
  status.text=if(apps.isEmpty())"لم تظهر تطبيقات مثبّتة من Google Play." else "اختَر تطبيقًا أو ابدأ جلسة Turbo."
  if(::list.isInitialized) render(search.text?.toString().orEmpty())
 }
 private fun render(q:String){
  if(!::list.isInitialized)return
  list.removeAllViews()
  val found=apps.filter{it.name.contains(q,true)||it.pkg.contains(q,true)}
  if(found.isEmpty()){list.addView(label("مفيش نتائج مطابقة",14,0xFF8E9AB8.toInt(),false).apply{gravity=Gravity.CENTER;setPadding(0,dp(24),0,dp(24))});return}
  found.forEach{app->
   val card=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(13),dp(12),dp(10),dp(12));setBackgroundColor(0xFF11182C.toInt())}
   val icon=ImageView(this).apply{setImageDrawable(app.icon)};card.addView(icon,lp(dp(42),dp(42)))
   val col=LinearLayout(this).apply{orientation=1;setPadding(dp(12),0,dp(6),0)}
   col.addView(label(app.name,14,Color.WHITE,true))
   col.addView(label(app.pkg,10,0xFF7E8CAE.toInt(),false).apply{setPadding(0,dp(4),0,0)})
   card.addView(col,LinearLayout.LayoutParams(0,-2,1f))
   val b=button("Turbo",mint,bg).apply{textSize=12f; minWidth=dp(68);setPadding(dp(8),0,dp(8),0);setOnClickListener{
    if(!enabled()){status.text="فعّل المساعد من إعدادات إمكانية الوصول أولاً.";startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
    else startTurbo(listOf(app.pkg))
   }}
   card.addView(b,lp(dp(76),dp(42)));list.addView(card,lp(-1,-2, bottom=8))
  }
 }
 private fun startTurbo(pkgs:List<String>){
  val arr=JSONArray();pkgs.forEach{arr.put(it)}
  prefs.edit().putString("queue",arr.toString()).putInt("index",0).putInt("stage",0).apply()
  status.text="بدأت جلسة Turbo. قد تختلف الخطوات حسب إصدار Android."
  openInfo(pkgs.first())
 }
 private fun openInfo(pkg:String){try{startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$pkg")))}catch(_:Exception){status.text="تعذّر فتح إعدادات التطبيق."}}
 private fun enabled():Boolean{
  val m=getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
  return m.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any{it.resolveInfo.serviceInfo.packageName==packageName&&it.resolveInfo.serviceInfo.name.endsWith("TurboAccessibilityService")}
 }
 private fun label(s:String,size:Int,color:Int,bold:Boolean)=TextView(this).apply{text=s; textSize=size.toFloat();setTextColor(color);if(bold)typeface=Typeface.DEFAULT_BOLD}
 private fun button(s:String,color:Int,textColor:Int)=MaterialButton(this).apply{text=s;textAllCaps=false;textSize=14f;setTextColor(textColor);backgroundTintList=android.content.res.ColorStateList.valueOf(color);cornerRadius=dp(16)}
 private fun lp(w:Int,h:Int,top:Int=0,bottom:Int=0)=LinearLayout.LayoutParams(w,h).apply{topMargin=dp(top);bottomMargin=dp(bottom)}
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
