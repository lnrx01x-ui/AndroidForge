package com.turbonova.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout list;
    private TextView status;
    private final ArrayList<AppItem> apps = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        loadApps();
    }

    private TextView tv(String s, float size) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(Color.WHITE);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 20, 24, 16);
        root.setBackgroundColor(Color.rgb(11,16,32));

        TextView title = tv("TURBO NOVA", 28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, 60));

        TextView sub = tv("تنظيف وإيقاف التطبيقات التي ثبتّها من Google Play", 14);
        sub.setTextColor(Color.rgb(180,190,210));
        root.addView(sub, new LinearLayout.LayoutParams(-1, 48));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button access = button("صلاحية التحكم");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        actions.addView(access, new LinearLayout.LayoutParams(0, 58, 1));

        Button turbo = button("⚡ TURBO ALL");
        turbo.setOnClickListener(v -> {
            if (apps.size() > 0) TurboAccessibilityService.startQueue(this, apps);
            else Toast.makeText(this, "لا توجد تطبيقات Google Play ظاهرة", Toast.LENGTH_SHORT).show();
        });
        actions.addView(turbo, new LinearLayout.LayoutParams(0, 58, 1));
        root.addView(actions);

        status = tv("جاري البحث عن تطبيقات Google Play…", 13);
        status.setTextColor(Color.rgb(99,230,190));
        root.addView(status, new LinearLayout.LayoutParams(-1, 44));

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
    }

    private void loadApps() {
        new Thread(() -> {
            ArrayList<AppItem> found = new ArrayList<>();
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> infos = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo info : infos) {
                if ((info.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                try {
                    PackageInfo pi = pm.getPackageInfo(info.packageName, 0);
                    String installer = pm.getInstallSourceInfo(info.packageName).getInstallingPackageName();
                    if (!"com.android.vending".equals(installer)) continue;
                    CharSequence label = info.loadLabel(pm);
                    found.add(new AppItem(info.packageName, label == null ? info.packageName : label.toString()));
                } catch (Exception ignored) {}
            }
            Collections.sort(found, Comparator.comparing(a -> a.name.toLowerCase()));
            runOnUiThread(() -> {
                apps.clear();
                apps.addAll(found);
                list.removeAllViews();
                for (AppItem a : apps) addRow(a);
                status.setText(apps.size() + " تطبيق من Google Play");
            });
        }).start();
    }

    private void addRow(AppItem app) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(14, 8, 8, 8);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = tv(app.name, 16);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        row.addView(name, new LinearLayout.LayoutParams(0, 64, 1));

        Button turbo = button("Turbo");
        turbo.setOnClickListener(v -> TurboAccessibilityService.startQueue(this, Collections.singletonList(app)));
        row.addView(turbo, new LinearLayout.LayoutParams(110, 58));

        list.addView(row, new LinearLayout.LayoutParams(-1, 76));
    }

    public static class AppItem {
        public final String pkg, name;
        public AppItem(String p, String n) { pkg=p; name=n; }
    }
}
