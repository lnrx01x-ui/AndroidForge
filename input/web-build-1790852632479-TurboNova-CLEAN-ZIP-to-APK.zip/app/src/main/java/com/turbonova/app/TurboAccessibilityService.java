package com.turbonova.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityNodeInfo;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.List;

public class TurboAccessibilityService extends AccessibilityService {
    private static TurboAccessibilityService instance;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ArrayList<String> queue = new ArrayList<>();
    private int index = 0;
    private boolean running = false;
    private long lastAction = 0;

    @Override public void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (!running) return;
        if (System.currentTimeMillis() - lastAction < 500) return;
        lastAction = System.currentTimeMillis();
        h.postDelayed(this::drive, 220);
    }
    @Override public void onInterrupt() {}

    public static void startQueue(Context c, List<MainActivity.AppItem> apps) {
        if (instance == null) {
            c.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        instance.queue.clear();
        for (MainActivity.AppItem a : apps) instance.queue.add(a.pkg);
        instance.index = 0;
        instance.running = true;
        instance.openCurrent();
    }

    private void openCurrent() {
        if (!running || index >= queue.size()) {
            running = false;
            return;
        }
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.setData(Uri.parse("package:" + queue.get(index)));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void drive() {
        if (!running || index >= queue.size()) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        String pkg = root.getPackageName() == null ? "" : root.getPackageName().toString();
        if (pkg.equals("com.android.settings")) {
            if (clickAny(root, "Storage & cache", "Storage", "التخزين", "التخزين وذاكرة التخزين المؤقت")) {
                schedule();
                return;
            }
            if (clickAny(root, "Clear cache", "Clear cache", "مسح ذاكرة التخزين المؤقت", "مسح الكاش")) {
                schedule();
                return;
            }
            if (clickAny(root, "Force stop", "Force stop", "إيقاف إجباري", "فرض الإيقاف")) {
                schedule();
                return;
            }
            if (clickAny(root, "OK", "OK", "موافق", "حسنًا")) {
                schedule();
                return;
            }
        }
        schedule();
    }

    private boolean clickAny(AccessibilityNodeInfo root, String... labels) {
        for (String label : labels) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(label);
            for (AccessibilityNodeInfo n : nodes) {
                if (n != null && n.isVisibleToUser() && n.isEnabled()) {
                    AccessibilityNodeInfo x = n;
                    while (x != null && !x.isClickable()) x = x.getParent();
                    if (x != null && x.isClickable()) {
                        x.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void schedule() {
        h.postDelayed(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                String text = root.getText() == null ? "" : root.getText().toString();
                if (text.contains("App info") || text.contains("معلومات التطبيق")) {
                    // continue through the normal event loop
                }
            }
            if (running) {
                // If settings remains on the current app after the actions,
                // move to the next app after a short delay.
                h.postDelayed(() -> {
                    index++;
                    if (index < queue.size()) openCurrent();
                    else running = false;
                }, 700);
            }
        }, 500);
    }
}
