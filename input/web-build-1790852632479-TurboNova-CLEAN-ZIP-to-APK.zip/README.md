# Turbo Nova — CLEAN Android Project

A personal, no-root Android utility that uses Accessibility only to automate
the Android Settings screens for clearing cache and force-stopping selected
apps installed from Google Play.

Important:
- It does not use root.
- Android does not expose a general public API for clearing another app's cache
  or force-stopping it, so this project automates the Settings UI through
  Accessibility.
- Settings labels and flows vary by Android/OEM; manual confirmation may still
  appear.
- This project intentionally uses only the Android SDK and no external UI
  libraries, to keep ZIP-to-APK builds simple and reliable.

Build:
    gradle assembleDebug

Expected app label:
    Turbo Nova

Expected applicationId:
    com.turbonova.app
